--[[
	� 2014 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

Clockwork.config:Add("remove_map_physics", false, nil, nil, nil, nil, true);

cwCleanedMaps.entityList = {
	"item_healthcharger",
	"item_suitcharger",
	"weapon_*"
};